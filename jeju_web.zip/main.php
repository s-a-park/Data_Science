<?php
       
      // echo "mysql 연결 테스트<br>";

       $db = mysqli_connect("localhost","root","pass","travel");

      // if($db){
        //   echo "connect : 성공<br>";
     //  }
     //  else{
       //    echo "disconnect : 실패<br>";
     //  }


     //if(isset($_GET['stay'])){$stay = $_GET['stay'];} 
      
      //elseif(isset($_GET['eatery'])){$eatery = $_GET['eatery'];}
     // elseif(isset($_GET['spot'])){$spot = $_GET['spot'];}
       // elseif(isset($_GET['nature'])){$nature = $_GET['nature'];}
          // elseif(isset($_GET['olle'])){$olle = $_GET['olle'];}

       $add1 = $_GET["addr_1"];
       $add2 = $_GET["addr_2"];
       
       if(isset($_GET['stay'])){
        $stay = $_GET['stay']; 
        $sql = "SELECT Stay_Type, Stay_Name, Stay_Addr, Stay_Num FROM stay WHERE stay_Addr LIKE '%$add1%' and stay_Addr LIKE '%$add2%' ORDER BY stay_Name ASC";
       
        $result = mysqli_query($db,$sql);
        $num=1;
        $fields = mysqli_num_fields($result);
        
        echo "<table border=1>
         <th>번호</th> <th>숙소 타입</th> <th>숙소 이름</th> <th>주소</th> <th>전화번호</th> <tr>";
         
        while ($row = mysqli_fetch_row($result)){
         
            echo "<td>$num</td>";  
           
            for($i=0;$i<$fields;$i++){
               echo "<td>$row[$i]</td>";
            };
            echo "</tr>";
            $num++;
            
        };
    }
       elseif(isset($_GET['spot'])){
        $spot = $_GET['spot'];
        $sql = "SELECT Spot_Type, Spot_Name, Spot_Addr FROM spot WHERE spot_Addr LIKE '%$add1%' and spot_Addr LIKE '%$add2%' ORDER BY spot_Name ASC";
      
        $result = mysqli_query($db,$sql);
        $num=1;
        $fields = mysqli_num_fields($result);
        
        echo "<table border=1>
         <th>번호</th> <th>관광지 타입</th> <th>관광지 이름</th> <th>주소</th> <tr>";
         
        while ($row = mysqli_fetch_row($result)){
         
            echo "<td>$num</td>";  
           
            for($i=0;$i<$fields;$i++){
               echo "<td>$row[$i]</td>";
            };
            echo "</tr>";
            $num++;
            
        };
    
    }
       elseif(isset($_GET['eatery'])){
        $eatery = $_GET['eatery'];
        $sql = "SELECT eatery_Name, eatery_Addr,eatery_Num FROM eatery WHERE eatery_Addr LIKE '%$add1%' and eatery_Addr LIKE '%$add2%' ORDER BY eatery_Name ASC";
       
        $result = mysqli_query($db,$sql);
        $num=1;
        $fields = mysqli_num_fields($result);
        
        echo "<table border=1>
         <th>번호</th> <th>음식점 이름</th> <th>주소</th> <th>전화번호</th> <tr>";
         
        while ($row = mysqli_fetch_row($result)){
         
            echo "<td>$num</td>";  
           
            for($i=0;$i<$fields;$i++){
               echo "<td>$row[$i]</td>";
            };
            echo "</tr>";
            $num++;
            
        };
    }
       elseif(isset($_GET['nature'])){
        $nature = $_GET['nature'];
        $sql = "SELECT nature_Type, nature_Name, nature_Addr FROM nature WHERE nature_Addr LIKE '%$add1%' and nature_Addr LIKE '%$add2%' ORDER BY nature_Name ASC";
      
        $result = mysqli_query($db,$sql);
        $num=1;
        $fields = mysqli_num_fields($result);
        
        echo "<table border=1>
         <th>번호</th> <th>자연관광지 타입</th> <th>자연관광지 이름</th> <th>주소</th> <tr>";
         
        while ($row = mysqli_fetch_row($result)){
         
            echo "<td>$num</td>";  
           
            for($i=0;$i<$fields;$i++){
               echo "<td>$row[$i]</td>";
            };
            echo "</tr>";
            $num++;
            
        };
    }
       elseif(isset($_GET['olle'])){
        $olle = $_GET['olle'];
        $sql = "SELECT olle_Name, olle_start, olle_end, olle_distance, olle_time FROM olle WHERE olle_start LIKE '%$add1%' and olle_start LIKE '%$add2%' ORDER BY olle_Name ASC";
       
        $result = mysqli_query($db,$sql);
        $num=1;
        $fields = mysqli_num_fields($result);
        
        echo "<table border=1>
         <th>번호</th> <th>올레길 이름</th> <th>시작 지점</th> <th>종료 지점</th> <th>총 거리</th> <th>걸리는 시간</th> <tr>";
         
        while ($row = mysqli_fetch_row($result)){
         
            echo "<td>$num</td>";  
           
            for($i=0;$i<$fields;$i++){
               echo "<td>$row[$i]</td>";
            };
            echo "</tr>";
            $num++;
            
        };
    
    }
      else{ echo "모든 버튼을 입력해야 결과가 나옵니다";}
      
       
        echo "</table>"

    
        
       
      
      ?>

        
<?php
       
      // echo "mysql 연결 테스트<br>";

       $db = mysqli_connect("localhost","root","pass","travel");

       //if($db){
      //     echo "connect : 성공<br>";
       //}
      // else{
      //     echo "disconnect : 실패<br>";
     //  }


     //if(isset($_GET['stay'])){$stay = $_GET['stay'];} 
      
      //elseif(isset($_GET['eatery'])){$eatery = $_GET['eatery'];}
     // elseif(isset($_GET['spot'])){$spot = $_GET['spot'];}
       // elseif(isset($_GET['nature'])){$nature = $_GET['nature'];}
          // elseif(isset($_GET['olle'])){$olle = $_GET['olle'];}

       
       $add2 = $_GET["addr_2"];

        $sql = "SELECT avg(r_eatery_Score) , avg(r_stay_Score) , avg(r_spot_Score) from r_eatery,r_stay,r_spot
        where R_Eatery_Addr like '%$add2%' and R_Stay_Addr like '%$add2%' and R_Spot_Addr like '%$add2%' ";
       
        $result = mysqli_query($db,$sql);
        $num=1;
        $fields = mysqli_num_fields($result);
        
        echo "<table border=1>
         <th>번호</th> <th>$add2 의 음식점 별점 평균</th> <th>$add2 의 숙소 별점 평균</th> <th> $add2 의 관광지 별점 평균</th> <tr>";
         
        while ($row = mysqli_fetch_row($result)){
         
            echo "<td>$num</td>";  
           
            for($i=0;$i<$fields;$i++){
               echo "<td>$row[$i]</td>";
            };
            echo "</tr>";
            $num++;
            
        }
    
       

        echo "</table>"

    
        
       
      
      ?>
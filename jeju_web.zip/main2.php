<?php
       
      // echo "mysql 연결 테스트<br>";

       $db = mysqli_connect("localhost","root","pass","travel");

      // if($db){
      //     echo "connect : 성공<br>";
      // }
      // else{
      //     echo "disconnect : 실패<br>";
      // }

       $text_stay = $_GET["text_stay"];

       if(isset($_GET['text_stay'])){
        $text_stay = $_GET['text_stay']; 
        $sql = "SELECT spot_name,Spot_langtitude, Spot_longtitude from spot
        where Spot_langtitude <= any(select Stay_langtitude + 0.00839 from stay 
        where Stay_Name like '%$text_stay%') 
        and Spot_langtitude >= any(select Spot_langtitude -0.00839 from stay where Stay_Name like '%$text_stay%')
        and Spot_longtitude <= any(select Stay_longtitude + 0.11260 from stay where Stay_Name like '%$text_stay%')
        and Spot_longtitude >= any(select Spot_longtitude - 0.11260 from stay where Stay_Name like '%$text_stay%')
        order by Spot_longtitude asc";

$result = mysqli_query($db,$sql);
$num=1;
$fields = mysqli_num_fields($result);
echo "입력한 📌 $text_stay 📌 반경 1km이내의 관광지 목록 입니다.";
echo "<table border=1>
 <th>번호</th> <th>관광지 이름</th> <th>관광지 경도</th> <th>관광지 위도</th> <tr>";
 
while ($row = mysqli_fetch_row($result)){
 
    echo "<td>$num</td>";  
   
    for($i=0;$i<$fields;$i++){
       echo "<td>$row[$i]</td>";
    };
    echo "</tr>";
    $num++;
    
};
       }
       echo "</table>"
       ?>